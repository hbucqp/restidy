# restidy


## Installation
```
pip3 install restidy==0.2.2
```


## Usage
```
usage: resfidner_tidy.py -i <resfinder_result_directory> -o <output_file_directory>

optional arguments:
  -h, --help  show this help message and exit

  -i I        <input_path>: resfinder_result_path

  -o O        <output_file_path>: output_file_path
```
